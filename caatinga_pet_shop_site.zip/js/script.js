document.addEventListener('DOMContentLoaded', function() {
    // Menu mobile
    const mobileMenuIcon = document.querySelector('.mobile-menu-icon');
    const navMenu = document.querySelector('nav ul');
    
    if (mobileMenuIcon) {
        mobileMenuIcon.addEventListener('click', function() {
            navMenu.classList.toggle('show');
        });
    }
    
    // Navegação suave para as seções
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                window.scrollTo({
                    top: targetSection.offsetTop - 80,
                    behavior: 'smooth'
                });
                
                // Fechar menu mobile se estiver aberto
                if (navMenu.classList.contains('show')) {
                    navMenu.classList.remove('show');
                }
            }
        });
    });
    
    // Calendário de promoções
    const months = [
        'janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho',
        'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'
    ];
    
    let currentMonthIndex = 0;
    const currentMonthElement = document.querySelector('.current-month');
    const prevMonthButton = document.querySelector('.prev-month');
    const nextMonthButton = document.querySelector('.next-month');
    
    // Configurar conteúdo para todos os meses
    const monthsContent = {
        janeiro: {
            tema: "Verão Pet Saudável e Liquidação de Ano Novo",
            promocaoPrincipal: "Pacote de verão com desconto de 15% em consulta + vacina + antipulgas",
            produtosDestaque: "Produtos para viagem e proteção contra o calor",
            acaoEspecial: "Liquidação de produtos não vendidos em dezembro (20% a 30% de desconto)"
        },
        fevereiro: {
            tema: "Mês dos Felinos (Dia Mundial do Gato - 17/02)",
            promocaoPrincipal: "20% de desconto em todos os produtos e serviços para gatos",
            produtosDestaque: "Arranhadores, rações premium para gatos, brinquedos interativos",
            acaoEspecial: "Campanha de adoção responsável em parceria com protetores locais"
        },
        março: {
            tema: "Preparação para o Outono (Início do Outono - 20/03)",
            promocaoPrincipal: "Check-up pré-outono com 15% de desconto",
            produtosDestaque: "Suplementos para articulações, produtos para cuidados respiratórios",
            acaoEspecial: "Palestra sobre cuidados sazonais com pets"
        },
        abril: {
            tema: "Mês da Prevenção",
            promocaoPrincipal: "Pacote de vermifugação com 10% de desconto",
            produtosDestaque: "Vermífugos, produtos para higiene bucal, suplementos vitamínicos",
            acaoEspecial: "Distribuição de cartilha digital sobre prevenção de doenças"
        },
        maio: {
            tema: "Mães de Pet (Dia das Mães) e Adoção Responsável (25/05)",
            promocaoPrincipal: "Kit 'Mãe de Pet' com 15% de desconto",
            produtosDestaque: "Produtos para pets recém-adotados, kits de presente",
            acaoEspecial: "Feira de adoção em parceria com ONGs locais"
        },
        junho: {
            tema: "Preparação para o Inverno (Início do Inverno - 21/06)",
            promocaoPrincipal: "15% de desconto em consultas relacionadas a problemas respiratórios",
            produtosDestaque: "Roupas de inverno para pets, camas e cobertores",
            acaoEspecial: "Arrecadação de cobertores usados para abrigos de animais"
        },
        julho: {
            tema: "Mês do Vira-Lata (31/07) e Férias Escolares",
            promocaoPrincipal: "Pacote especial de banho e tosa para vira-latas (20% de desconto)",
            produtosDestaque: "Brinquedos para estimulação mental, petiscos educativos",
            acaoEspecial: "Concurso 'Vira-lata mais charmoso da cidade' com premiação"
        },
        agosto: {
            tema: "Mês dos Cães e dos Pais (Dia Mundial do Cachorro - 26/08 e Dia dos Pais)",
            promocaoPrincipal: "Campanha de vacinação antirrábica com preço promocional",
            produtosDestaque: "Produtos para passeio, kits 'Pai e Pet'",
            acaoEspecial: "Sorteio de ensaio fotográfico para 'pais de pet'"
        },
        setembro: {
            tema: "Primavera Pet (Início da Primavera - 22/09) e Mês do Cliente (15/09)",
            promocaoPrincipal: "Descontos progressivos para clientes fiéis (5%, 10% ou 15%)",
            produtosDestaque: "Produtos anti-alérgicos, repelentes naturais",
            acaoEspecial: "Café da manhã especial para clientes VIP (um sábado do mês)"
        },
        outubro: {
            tema: "Mês dos Animais (Dia Mundial dos Animais - 04/10)",
            promocaoPrincipal: "Semana de avaliação gratuita (check-up básico sem custo)",
            produtosDestaque: "Rações premium com desconto, produtos naturais",
            acaoEspecial: "Campanha de arrecadação para abrigos locais"
        },
        novembro: {
            tema: "Black Friday Pet (Penúltima sexta-feira) e Doação de Sangue (25/11)",
            promocaoPrincipal: "Descontos Black Friday (até 40% em produtos selecionados)",
            produtosDestaque: "Produtos de maior valor com descontos especiais",
            acaoEspecial: "Campanha de conscientização sobre doação de sangue animal"
        },
        dezembro: {
            tema: "Natal Pet e Dezembro Verde (Conscientização contra abandono)",
            promocaoPrincipal: "Kits de Natal personalizados com 15% de desconto",
            produtosDestaque: "Brinquedos temáticos de Natal, produtos para o verão",
            acaoEspecial: "Decoração especial com 'Trono do Papai Noel' para fotos com pets"
        }
    };
    
    // Função para atualizar o conteúdo do mês
    function updateMonthContent() {
        const monthName = months[currentMonthIndex];
        currentMonthElement.textContent = monthName.charAt(0).toUpperCase() + monthName.slice(1);
        
        // Esconder todos os meses
        document.querySelectorAll('.month-details').forEach(month => {
            month.style.display = 'none';
        });
        
        // Mostrar o mês atual ou criar se não existir
        let currentMonthElement = document.getElementById(monthName);
        if (!currentMonthElement) {
            const monthData = monthsContent[monthName];
            currentMonthElement = createMonthElement(monthName, monthData);
            document.querySelector('.calendar-container').appendChild(currentMonthElement);
        }
        
        currentMonthElement.style.display = 'block';
    }
    
    // Função para criar elemento de mês
    function createMonthElement(monthName, data) {
        const monthElement = document.createElement('div');
        monthElement.className = 'month-details';
        monthElement.id = monthName;
        
        monthElement.innerHTML = `
            <h4>Tema: "${data.tema}"</h4>
            <div class="promotion-details">
                <div class="detail">
                    <h5>Promoção Principal</h5>
                    <p>${data.promocaoPrincipal}</p>
                </div>
                <div class="detail">
                    <h5>Produtos em Destaque</h5>
                    <p>${data.produtosDestaque}</p>
                </div>
                <div class="detail">
                    <h5>Ação Especial</h5>
                    <p>${data.acaoEspecial}</p>
                </div>
            </div>
        `;
        
        return monthElement;
    }
    
    // Configurar navegação do calendário
    if (prevMonthButton && nextMonthButton) {
        prevMonthButton.addEventListener('click', function() {
            currentMonthIndex = (currentMonthIndex - 1 + 12) % 12;
            updateMonthContent();
        });
        
        nextMonthButton.addEventListener('click', function() {
            currentMonthIndex = (currentMonthIndex + 1) % 12;
            updateMonthContent();
        });
        
        // Inicializar com o mês atual
        updateMonthContent();
    }
    
    // Animação ao scroll
    const animateOnScroll = function() {
        const sections = document.querySelectorAll('section');
        
        sections.forEach(section => {
            const sectionTop = section.getBoundingClientRect().top;
            const windowHeight = window.innerHeight;
            
            if (sectionTop < windowHeight * 0.75) {
                section.classList.add('animate');
            }
        });
    };
    
    // Adicionar classe de animação ao carregar a página
    animateOnScroll();
    
    // Adicionar evento de scroll para animação
    window.addEventListener('scroll', animateOnScroll);
});
